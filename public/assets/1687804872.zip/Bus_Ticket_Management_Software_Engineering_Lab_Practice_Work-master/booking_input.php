<h1>Create Record</h1>

<form method="GET" action="booking.php">

	Name: <input type="text" name="name"> 
    <br>
    Date: <input type="text" name="date"> 
    <br>
    From: <input type="text" name="from"> 
    <br>
    To: <input type="text" name="to"> 
    <br>

    <input type="submit">

</form>

<button> <a href = 'index.php'> Home </a> </button>