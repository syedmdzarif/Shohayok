<h1>Record by ID</h1>

<form method="GET" action="ticketing_history_id_backend.php">

	ID: <input type="text" name="id"> 
    <br>
    
    <input type="submit">

</form>

<button> <a href = 'index.php'> Home </a> </button>