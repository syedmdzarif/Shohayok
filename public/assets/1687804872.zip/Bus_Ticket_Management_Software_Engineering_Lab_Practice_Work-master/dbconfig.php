<?php
	define( 'HOST', 'localhost' );
	define( 'DB', 'bus_ticket_management' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>