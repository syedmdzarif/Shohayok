<h1>Record by name</h1>

<form method="GET" action="ticketing_history_user_backend.php">

	Name: <input type="text" name="name"> 
    <br>
    

    <input type="submit">

</form>

<button> <a href = 'index.php'> Home </a> </button>